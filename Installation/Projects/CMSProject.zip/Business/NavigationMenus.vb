﻿Imports Data
Imports Model
Imports CommonLibrary.Members

Public Class NavigationMenus

    Public Function GetAdminNavigationMenuByUser(ByVal UserId As Integer, ByVal PermissionTypeId As Integer, ByVal IsParent As Boolean) As List(Of v_GetMenuByUser)
        Dim MR As New MenusRepository
        Dim AdminMenu As List(Of v_GetMenuByUser) = MR.GetMenuByUser(enumPermissionsType.BackEnd, UserId)

        If IsParent Then
            AdminMenu = (From item In AdminMenu
                         Where item.MenuParentId = 0
                         Order By item.MenuOrder Ascending
                         Select item).ToList()
        Else
            AdminMenu = (From item In AdminMenu
                         Where item.MenuParentId <> 0 _
                         And (item.UserId <> 0 Or item.UserId IsNot Nothing)
                         Order By item.MenuOrder Ascending, item.MenuParentId Ascending
                         Select item).ToList()
        End If


        Return AdminMenu
    End Function

    Public Function GetActiveMenuByType(ByVal PermissionTypeId As Integer) As List(Of Menu)
        Dim MR As New MenusRepository
        Dim lstMenu As New List(Of Menu)
        lstMenu = MR.GetMenuByType(PermissionTypeId)

        lstMenu = (From item In lstMenu
                   Where item.IsActive = True
                   Select item).ToList()

        Return lstMenu
    End Function

    Public Function GetActiveSubMenusByType(ByVal PermissionTypeId As Integer, ByVal ParentMenuId As Integer) As List(Of Menu)
        Dim MR As New MenusRepository
        Dim lstMenu As New List(Of Menu)
        lstMenu = MR.GetSubMenusByType(PermissionTypeId, ParentMenuId)

        lstMenu = (From item In lstMenu
                   Where item.IsActive = True
                   Select item).ToList()

        Return lstMenu
    End Function

End Class
