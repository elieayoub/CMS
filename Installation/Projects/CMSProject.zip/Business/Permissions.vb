﻿Imports Data
Imports Model
Imports CommonLibrary.Members

Public Class Permissions

    'public function hasusercontrolpermission(byval userid as integer, byval controlid as integer) as boolean
    '    dim haspermission as boolean = false
    '    dim dbmodel as new abc_cmsapplicationentities
    '    dim pagepermission as new list(of pagespermission)

    '    pagepermission = (from p in dbmodel.pagespermissions
    '                      join c in dbmodel.permissionscontrols on c.permissioncontrolpagepermissionid equals p.pagepermissionid
    '                      join r in dbmodel.rolespermissions on r.pagepermissionid equals p.pagepermissionid
    '                      join u in dbmodel.usersroles on u.roleid equals r.roleid
    '                      where u.userid = userid _
    '                      and c.permissioncontrolid = controlid
    '                      select p).tolist()

    '    if pagepermission.count > 0 then
    '        haspermission = true
    '    end if

    '    return haspermission
    'end function

    Public Function GetUserControlPermissionAction(ByVal UserId As Integer, ByVal ControlId As Integer) As PermissionsAction
        Dim hasPermission As Boolean = False
        Dim dbModel As New ABC_CMSApplicationEntities
        Dim UserPermissionAction As New PermissionsAction

        UserPermissionAction = (From A In dbModel.PermissionsActions
                                Join UR In dbModel.UsersRoles On UR.RoleId Equals A.PermissionActionRoleId
                                Join U In dbModel.Users On U.UserId Equals UR.UserId
                                Where U.UserId = UserId _
                                And U.IsActive = True _
                                And A.PermissionActionPermissionControlId = ControlId
                                Select A).FirstOrDefault()

        Return UserPermissionAction
    End Function

    Public Function hasUserControlsPermissions(ByVal UserActionId As Integer, ByVal ControlId As Integer, ByVal UserId As Integer) As Boolean
        Dim hasControlPermission As Boolean = False
        Dim UserPermissionAction As New PermissionsAction

        UserPermissionAction = GetUserControlPermissionAction(UserId, ControlId)

        Select Case UserActionId
            Case enumUsersActions.Create
                If (UserPermissionAction.Create = True) Then hasControlPermission = True
            Case enumUsersActions.Read
                If (UserPermissionAction.Read = True) Then hasControlPermission = True
            Case enumUsersActions.Update
                If (UserPermissionAction.Update = True) Then hasControlPermission = True
            Case enumUsersActions.Delete
                If (UserPermissionAction.Delete = True) Then hasControlPermission = True
            Case Else
        End Select

        Return hasControlPermission
    End Function

    Public Function hasUserControlPermission(ByVal UserActionId As Integer, ByVal ControlId As Integer, ByVal UserId As Integer) As Boolean
        Dim hasPermissions As Boolean = False
        Dim clsPermissions As New Business.Permissions

        hasPermissions = clsPermissions.hasUserControlsPermissions(UserActionId, ControlId, UserId)
        Return hasPermissions
    End Function


End Class
